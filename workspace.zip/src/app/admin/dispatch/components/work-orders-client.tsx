"use client";

import { useState, useMemo, useEffect } from "react";
import type { WorkOrder, Technician, Recommendation, Route } from "@/lib/types";
import { getRecommendation } from "../actions";
import { format, parseISO } from "date-fns";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

import {
  Calendar,
  Clock,
  MapPin,
  Pencil,
  UserPlus,
  DollarSign,
  User,
  Send,
  ShieldCheck,
  Eye,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Activity,
  Gauge
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { JobDetailDialog } from "@/components/job-detail-dialog";
import { cn } from "@/lib/utils";
import { isPayAdmin } from "@/lib/permissions";
import { getReliabilityTier, getTierBadgeVariant } from "@/lib/reliability";

type WorkOrdersClientProps = {
  workOrders: WorkOrder[];
  allWorkOrders: WorkOrder[];
  technicians: Technician[];
  onWorkOrdersChange: (orders: WorkOrder[]) => void;
  routes: Route[];
  mode: 'unassigned' | 'assigned';
};

export function WorkOrdersClient({
  workOrders,
  allWorkOrders,
  technicians,
  onWorkOrdersChange,
  routes,
  mode
}: WorkOrdersClientProps) {
  const [selectedOrder, setSelectedOrder] = useState<WorkOrder | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [recommendation, setRecommendation] = useState<Recommendation | null>(
    null
  );
  const [techSearchQuery, setTechSearchQuery] = useState("");

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editedOrder, setEditedOrder] = useState<WorkOrder | null>(null);

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [detailJob, setDetailJob] = useState<WorkOrder | null>(null);

  const [currentUser, setCurrentUser] = useState<Technician | null>(null);

  const { toast } = useToast();

  useEffect(() => {
    const userId = localStorage.getItem('currentUserId');
    if (userId) {
      setCurrentUser(technicians.find(t => t.id === userId) || null);
    }
  }, [technicians]);

  useEffect(() => {
    setCurrentPage(1);
  }, [workOrders.length, itemsPerPage]);

  const sortedWorkOrders = useMemo(() => {
    return [...workOrders].sort((a, b) => a.scheduleDate.localeCompare(b.scheduleDate));
  }, [workOrders]);

  const totalPages = Math.ceil(sortedWorkOrders.length / itemsPerPage);
  const paginatedOrders = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return sortedWorkOrders.slice(start, start + itemsPerPage);
  }, [sortedWorkOrders, currentPage, itemsPerPage]);

  const handleOpenAssignDialog = (order: WorkOrder) => {
    setSelectedOrder(order);
    setRecommendation(null);
    setTechSearchQuery("");
    setIsDialogOpen(true);
  };

  const handleOpenEditDialog = (order: WorkOrder) => {
    setSelectedOrder(order);
    setEditedOrder({ ...order });
    setIsEditDialogOpen(true);
  };

  const handleOpenDetail = (order: WorkOrder) => {
    setDetailJob(order);
    setIsDetailOpen(true);
  };

  const handleGetRecommendation = async () => {
    if (!selectedOrder) return;
    setIsLoading(true);
    try {
      const result = await getRecommendation({
        workOrder: {
          id: selectedOrder.id,
          description: selectedOrder.description,
          location: selectedOrder.location,
          requiredSkills: selectedOrder.requiredSkills,
          priority: selectedOrder.priority,
        },
        availableTechnicians: technicians.map((t) => ({
          id: t.id,
          name: t.name,
          currentLocation: t.currentLocation,
          reliabilityScore: t.reliabilityScore,
          currentWorkload: t.currentWorkload,
          skills: t.skills,
        })),
      });
      setRecommendation(result);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Recommendation Failed",
        description: "Could not get an AI recommendation.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAssign = (technicianId: string) => {
    if (!selectedOrder) return;
    const updated = allWorkOrders.map(order =>
      order.id === selectedOrder.id
        ? { ...order, status: 'assigned' as const, assignedTechnicianId: technicianId === 'unassigned' ? undefined : technicianId }
        : order
    );
    onWorkOrdersChange(updated);
    setIsDialogOpen(false);
    toast({
      title: "Allocation Committed",
      description: `Assignment ${selectedOrder.id.toUpperCase()} has been moved to the assigned registry.`,
    });
  }

  const handleSaveChanges = () => {
    if (!editedOrder || !selectedOrder) return;

    let finalUpdate = { ...editedOrder };
    const payChanged = editedOrder.pay !== selectedOrder.pay || editedOrder.payType !== selectedOrder.payType;
    const payAdmin = isPayAdmin(currentUser);

    if (payChanged && !payAdmin) {
      finalUpdate.pay = selectedOrder.pay;
      finalUpdate.payType = selectedOrder.payType;
      finalUpdate.payChangeRequest = {
        pay: editedOrder.pay,
        payType: editedOrder.payType,
        requestedBy: currentUser?.id || 'unknown',
        requestedAt: new Date().toISOString()
      };
      toast({
        title: "Pay Change Requested",
        description: "Financial modifications require Super Admin or Payroll Admin authorization. Request staged.",
      });
    } else if (payChanged && payAdmin) {
      finalUpdate.payChangeRequest = undefined;
      toast({ title: "Pay Parameters Updated", description: "Financial changes authorized and committed." });
    }

    const updated = allWorkOrders.map(order =>
      order.id === editedOrder.id ? finalUpdate : order
    );
    onWorkOrdersChange(updated);
    setIsEditDialogOpen(false);
  };

  const handleApprovePay = (orderId: string) => {
    const updated = allWorkOrders.map(o => {
      if (o.id === orderId && o.payChangeRequest) {
        return {
          ...o,
          pay: o.payChangeRequest.pay,
          payType: o.payChangeRequest.payType,
          payChangeRequest: undefined
        };
      }
      return o;
    });
    onWorkOrdersChange(updated);
    toast({ title: "Pay Authorized", description: "Registry updated with approved financial parameters." });
  };

  const handleJobUpdate = (woId: string, updates: Partial<WorkOrder>) => {
    const updated = allWorkOrders.map(order => 
        order.id === woId ? { ...order, ...updates } : order
    );
    onWorkOrdersChange(updated);
    if (detailJob?.id === woId) {
        setDetailJob(prev => prev ? { ...prev, ...updates } : null);
    }
  };

  const handleConfirmAssignments = () => {
    toast({
      title: "Transmission Initiated",
      description: `${workOrders.length} field assignments transmitted to operative terminals via secure protocol.`,
    });
  }

  const formatDateDisplay = (dateStr: string) => {
    if (!dateStr) return 'TBD';
    try {
      const parts = dateStr.split(/[-/]/);
      let d;
      if (parts[0].length === 4) { d = new Date(dateStr); } 
      else { d = parseISO(dateStr); }
      return format(d, 'MM-dd-yyyy');
    } catch (e) {
      return dateStr;
    }
  };

  const getFieldNationLink = (id: string) => {
    const cleanId = id.replace(/^wo-/, '');
    return `https://app.fieldnation.com/workorders/${cleanId}`;
  };

  const filteredTechniciansRegistry = useMemo(() => {
    return technicians
      .filter(t => !t.roles?.includes('client') && !t.role.toLowerCase().includes('client'))
      .filter(t => t.name.toLowerCase().includes(techSearchQuery.toLowerCase()))
      .map(tech => {
        const charSum = (str: string) => str.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
        const seed = Math.abs(charSum(tech.id) - charSum(selectedOrder?.id || ''));
        return { ...tech, distance: (seed % 35) + 1.2 };
      }).sort((a, b) => a.distance - b.distance);
  }, [technicians, selectedOrder, techSearchQuery]);

  return (
    <>
      {mode === 'assigned' && sortedWorkOrders.length > 0 && (
        <div className="mb-4 flex items-center justify-between p-4 rounded-lg bg-bg-tertiary border border-border-sub">
            <div className="flex items-center gap-3">
                <ShieldCheck className="text-text-green h-5 w-5" />
                <div>
                    <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest">Global Allocation</p>
                    <p className="text-xs font-bold text-text-primary uppercase">Ready for Assignment</p>
                </div>
            </div>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button className="h-9 bg-text-green hover:bg-text-green/90 px-6 border-none shadow-none text-white font-bold uppercase text-[10px] tracking-widest">
                    <Send className="mr-2 h-3.5 w-3.5" />
                    Send Out Assignments
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="bg-bg-elevated border-border-main">
                <AlertDialogHeader>
                  <AlertDialogTitle className="uppercase tracking-wider">Authorize Job Transmission?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will broadcast assignment details to {sortedWorkOrders.length} field operatives. This action initiates the live tracking window.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleConfirmAssignments} className="bg-text-green hover:bg-text-green/90 border-none">
                    Confirm & Notify
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
        </div>
      )}

      <div className="table-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th style={{ width: "200px" }} className="text-center">ID & Status</th>
              <th className="text-left pl-0">Assignment Intelligence</th>
              <th style={{ width: "160px" }} className="text-left pl-0">Schedule</th>
              <th style={{ width: "250px" }} className="text-left pl-0">Site Coordinates</th>
              <th style={{ width: "180px" }} className="text-center">{mode === 'assigned' ? 'Operative' : 'Settlement Pay'}</th>
              <th style={{ width: "120px" }} className="text-center"></th>
            </tr>
          </thead>
          <tbody>
            {paginatedOrders.map((order) => {
              const technician = technicians.find(t => t.id === order.assignedTechnicianId);
              
              return (
                <tr key={order.id} className="group">
                  <td>
                    <div className="flex flex-col items-center justify-center gap-1">
                      <div className="flex items-center gap-1.5">
                        <div className="cell-id !text-[10px] font-mono group-hover:text-brand-red transition-colors">{order.id.toUpperCase()}</div>
                        {order.source === 'Imported' && (
                          <a href={getFieldNationLink(order.id)} target="_blank" rel="noopener noreferrer" title="View on FieldNation" className="text-text-muted hover:text-brand-red transition-colors">
                            <ExternalLink size={10} />
                          </a>
                        )}
                      </div>
                      <Badge variant={order.status === 'unassigned' ? 'pending' : order.status} className="capitalize text-[8px] h-4 px-1.5">{order.status}</Badge>
                    </div>
                  </td>
                  <td className="!py-3 text-left pl-0">
                    <div className="flex items-center gap-4">
                      <div className="text-xs font-bold text-text-primary uppercase tracking-wide leading-tight group-hover:text-brand-red transition-colors">{order.description}</div>
                      <div className="text-[10px] font-bold text-text-muted uppercase tracking-widest whitespace-nowrap">{order.clientName}</div>
                    </div>
                  </td>
                  <td>
                    <div className="flex flex-col items-start justify-center gap-1 pl-0">
                      <div className="flex items-center gap-2 text-[10px] text-text-secondary font-mono">
                        <Calendar size={13} className="text-text-muted shrink-0" />
                        <span>{formatDateDisplay(order.scheduleDate)}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-text-secondary font-mono">
                        <Clock size={13} className="text-text-muted shrink-0" />
                        <span>{order.scheduleTime}</span>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center justify-start gap-2 text-[10px] text-text-secondary font-bold uppercase pl-0">
                      <MapPin size={10} className="text-brand-red shrink-0" />
                      <span className="truncate max-w-[200px]">{order.location}</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex flex-col items-center justify-center">
                        {mode === 'assigned' ? (
                            technician ? (
                                <div className="flex items-center gap-3">
                                    <Avatar className="h-8 w-8 border border-border-sub">
                                        <AvatarImage src={technician.avatarUrl} />
                                        <AvatarFallback>{technician.name.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    <div className="text-left">
                                        <p className="text-[10px] font-bold text-text-primary uppercase tracking-tight leading-none">{technician.name}</p>
                                        <div className="flex items-center gap-2 mt-1">
                                            <Badge variant={getTierBadgeVariant(technician.reliabilityTier || getReliabilityTier(technician.reliabilityScore))} className="text-[7px] h-3.5 px-1 uppercase tracking-tighter">
                                                {technician.reliabilityTier || getReliabilityTier(technician.reliabilityScore)}
                                            </Badge>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <span className="text-[10px] text-text-red uppercase font-bold tracking-widest">Unallocated</span>
                            )
                        ) : (
                            <div className="flex items-center gap-1.5 text-text-green">
                                <DollarSign size={12} className="shrink-0" />
                                <div className="flex flex-col items-start leading-none">
                                    <span className="font-mono text-xs font-bold">{order.pay.toFixed(2)}</span>
                                    <span className="text-[8px] uppercase font-bold tracking-widest text-text-muted mt-0.5">{order.payType}</span>
                                </div>
                            </div>
                        )}
                    </div>
                  </td>
                  <td>
                     <div className="flex items-center justify-center gap-1">
                       {order.status === 'unassigned' && (
                         <button 
                            className="h-6 rounded bg-brand-red hover:bg-brand-red-hover px-2 text-[9px] font-bold uppercase text-white flex items-center gap-1 transition-colors"
                            onClick={() => handleOpenAssignDialog(order)}
                         >
                            <UserPlus size={10}/> Assign
                         </button>
                       )}
                       <button className="h-6 w-6 flex items-center justify-center text-text-muted hover:text-text-primary transition-colors" onClick={() => handleOpenEditDialog(order)}>
                         <Pencil size={14} />
                       </button>
                       <button className="h-6 w-6 flex items-center justify-center text-text-muted hover:text-text-primary transition-colors" onClick={() => handleOpenDetail(order)}>
                         <Eye size={14} />
                       </button>
                     </div>
                  </td>
                </tr>
              );
            })}
             {sortedWorkOrders.length === 0 && (
                <tr><td colSpan={6} className="text-center py-12 text-text-muted italic font-bold uppercase tracking-widest text-xs opacity-40">Job pool clear. Awaiting further intake.</td></tr>
            )}
          </tbody>
        </table>

        {sortedWorkOrders.length > 0 && (
          <div className="bg-bg-tertiary/50 px-4 py-3 flex items-center justify-between border-t border-border-sub">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest">Show</p>
                <Select value={itemsPerPage.toString()} onValueChange={(v) => setItemsPerPage(parseInt(v))}>
                  <SelectTrigger className="h-7 w-[70px] bg-bg-primary text-[10px] font-bold border-border-sub">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <p className="text-[10px] font-bold text-text-muted uppercase tracking-widest">
                Showing <span className="text-text-primary">{(currentPage - 1) * itemsPerPage + 1}</span> to <span className="text-text-primary">{Math.min(currentPage * itemsPerPage, sortedWorkOrders.length)}</span> of <span className="text-text-primary">{sortedWorkOrders.length}</span> entries
              </p>
            </div>
            
            <div className="flex items-center gap-1">
              <Button 
                variant="outline" 
                size="icon-sm" 
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                className="h-7 w-7 border-border-sub bg-bg-primary"
              >
                <ChevronLeft size={14} />
              </Button>
              <div className="flex items-center gap-1 px-2">
                <span className="text-[10px] font-bold text-text-primary">Page {currentPage}</span>
                <span className="text-[10px] font-bold text-text-muted">of {totalPages}</span>
              </div>
              <Button 
                variant="outline" 
                size="icon-sm" 
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                className="h-7 w-7 border-border-sub bg-bg-primary"
              >
                <ChevronRight size={14} />
              </Button>
            </div>
          </div>
        )}
      </div>

      <JobDetailDialog 
        isOpen={isDetailOpen} 
        setIsOpen={setIsDetailOpen} 
        mission={detailJob} 
        onEdit={(m) => {
          setIsDetailOpen(false);
          handleOpenEditDialog(m);
        }}
        onUpdate={handleJobUpdate}
      />

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[750px] bg-bg-elevated border-border-default p-0 flex flex-col max-h-[90vh]">
          <DialogHeader className="p-6 pb-2">
            <DialogTitle className="page-title text-xl flex items-center gap-2">
              <UserPlus className="text-brand-red" size={20} />
              Dispatch Terminal
            </DialogTitle>
            <p className="text-xs text-text-muted">Select operative for individual job deployment: <span className="text-text-primary font-bold uppercase">{selectedOrder?.id}</span></p>
          </DialogHeader>
          <div className="flex-1 overflow-hidden px-6 pb-6 space-y-6 mt-4">
             <div className="relative">
                <Input 
                    placeholder="Search technician registry..." 
                    value={techSearchQuery}
                    onChange={(e) => setTechSearchQuery(e.target.value)}
                    className="bg-bg-primary h-11 text-sm uppercase font-bold tracking-wide"
                />
            </div>
            <div className="space-y-4">
                {!recommendation && !isLoading && (
                    <Button onClick={handleGetRecommendation} variant="secondary" className="w-full h-11">
                        <User className="mr-2 h-4 w-4"/> Initialize AI Dispatch Analysis
                    </Button>
                )}
                {isLoading && (
                    <div className="p-4 rounded-lg bg-bg-secondary border border-border-sub flex items-center justify-center gap-3">
                         <div className="h-4 w-4 rounded-full border-2 border-accent-gold border-t-transparent animate-spin" />
                         <span className="text-xs font-bold uppercase tracking-widest text-accent-gold">Calculating optimal operative...</span>
                    </div>
                )}
                {recommendation && (
                    <div className="rounded-lg border border-accent-gold bg-accent-gold-dim/10 p-4 flex items-center gap-4 animate-in fade-in slide-in-from-top-1 duration-300">
                        <div className="flex-1">
                            <p className="text-[10px] text-accent-gold font-black uppercase tracking-widest mb-1">AI Recommendation Intelligence</p>
                            <p className="text-xs text-text-primary leading-relaxed uppercase font-bold">{recommendation.reasoning}</p>
                        </div>
                    </div>
                )}
            </div>
            <Separator className="bg-border-sub" />
            <ScrollArea className="flex-1 rounded-md border border-border-sub bg-bg-primary">
                <div className="divide-y divide-border-sub">
                    {filteredTechniciansRegistry.map(tech => {
                        const tier = tech.reliabilityTier || getReliabilityTier(tech.reliabilityScore);
                        return (
                            <div key={tech.id} className="p-4 flex items-center justify-between group hover:bg-bg-tertiary transition-colors">
                                <div className="flex items-center gap-4">
                                    <Avatar className="h-10 w-10 border border-border-sub group-hover:border-brand-red transition-colors"><AvatarImage src={tech.avatarUrl} /></Avatar>
                                    <div>
                                        <div className="flex items-center gap-2">
                                            <p className="text-xs font-bold uppercase text-text-primary group-hover:border-brand-red transition-colors">{tech.name}</p>
                                            <Badge variant={getTierBadgeVariant(tier)} className="text-[7px] h-3.5 uppercase px-1.5">{tier}</Badge>
                                        </div>
                                        <div className="flex items-center gap-3 mt-1">
                                            <p className="text-[9px] text-text-muted uppercase font-bold tracking-tight flex items-center gap-1">
                                                <MapPin size={10} className="text-brand-red" /> {tech.distance?.toFixed(1) || '0.0'} MI FROM SITE
                                            </p>
                                            <div className="h-1 w-1 rounded-full bg-text-muted opacity-30" />
                                            <div className="flex items-center gap-1.5">
                                                <Gauge size={10} className="text-text-green" />
                                                <p className="text-[9px] text-text-green font-bold uppercase">{tech.reliabilityScore}% INDEX</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <Button 
                                    size="sm" 
                                    onClick={() => handleAssign(tech.id)} 
                                    className="h-8 text-[10px] px-6 uppercase font-bold"
                                >
                                    Select
                                </Button>
                            </div>
                        )
                    })}
                    {filteredTechniciansRegistry.length === 0 && (
                        <div className="p-12 text-center">
                            <p className="text-[10px] uppercase font-bold text-text-muted tracking-widest italic">No matching operatives in registry</p>
                        </div>
                    )}
                </div>
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[700px] bg-bg-elevated border-border-default max-h-[90vh] overflow-y-auto p-0 shadow-2xl">
            <DialogHeader className="p-6 pb-2">
                <DialogTitle className="text-lg font-bold uppercase tracking-widest text-text-primary">Update Assignment Parameters</DialogTitle>
                <p className="text-xs text-text-muted">Adjust manual parameters for assignment <span className="font-bold text-text-primary">{selectedOrder?.id.toUpperCase()}</span></p>
            </DialogHeader>
            {editedOrder && (
                <div className="px-6 py-4 space-y-6">
                    {editedOrder.payChangeRequest && (
                        <div className="p-4 rounded-lg bg-brand-red-dim/10 border border-brand-red/30 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <AlertTriangle className="text-brand-red h-5 w-5" />
                                <div>
                                    <p className="text-xs font-bold text-text-primary uppercase tracking-wide">Pay Change Pending Approval</p>
                                    <p className="text-[10px] text-text-muted uppercase tracking-widest">Requested: ${editedOrder.payChangeRequest.pay} ({editedOrder.payChangeRequest.payType})</p>
                                </div>
                            </div>
                            {isPayAdmin(currentUser) && (
                                <Button size="sm" className="h-8 bg-brand-red" onClick={() => handleApprovePay(editedOrder.id)}>
                                    <ShieldCheck size={14} className="mr-1.5"/> Authorize
                                </Button>
                            )}
                        </div>
                    )}

                    <div className="space-y-2">
                        <Label className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Job Title / Description</Label>
                        <Textarea 
                            placeholder="Primary objective and requirements..." 
                            value={editedOrder.description}
                            onChange={(e) => setEditedOrder({...editedOrder, description: e.target.value})}
                            className="bg-bg-primary border-border-sub h-20 text-xs"
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Client / Entity</Label>
                            <div className="space-y-1.5">
                                <Input 
                                    placeholder="Type client name..." 
                                    value={editedOrder.clientName}
                                    onChange={(e) => setEditedOrder({...editedOrder, clientName: e.target.value})}
                                    className="bg-bg-primary h-10 text-xs font-bold uppercase tracking-wide focus:border-brand-red transition-all"
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <Label className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Site Location</Label>
                            <div className="space-y-1.5">
                                <Input 
                                    placeholder="Full address or coordinates..." 
                                    value={editedOrder.location}
                                    onChange={(e) => setEditedOrder({...editedOrder, location: e.target.value})}
                                    className="bg-bg-primary h-10 text-xs focus:border-brand-red transition-all"
                                />
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                        <Label className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Settlement Pay ($)</Label>
                        <Input 
                            type="number"
                            placeholder="0.00"
                            value={editedOrder.pay || ''}
                            onChange={(e) => setEditedOrder({...editedOrder, pay: parseFloat(e.target.value) || 0})}
                            className="bg-bg-primary h-10 font-mono text-text-green text-sm"
                        />
                        </div>
                        <div className="space-y-2">
                        <Label className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Pay Model</Label>
                        <Select value={editedOrder.payType} onValueChange={(val: any) => setEditedOrder({...editedOrder, payType: val})}>
                            <SelectTrigger className="bg-bg-primary h-10 text-xs uppercase font-bold tracking-wider focus:ring-brand-red"><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="fixed">Fixed Rate</SelectItem>
                                <SelectItem value="hourly">Hourly Logic</SelectItem>
                                <SelectItem value="blended">Blended / Complex</SelectItem>
                            </SelectContent>
                        </Select>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                        <Label className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Schedule Date</Label>
                        <Input 
                            type="date"
                            value={editedOrder.scheduleDate}
                            onChange={(e) => setEditedOrder({...editedOrder, scheduleDate: e.target.value})}
                            className="bg-bg-primary h-10 text-xs"
                        />
                        </div>
                        <div className="space-y-2">
                        <Label className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Start Window</Label>
                        <Input 
                            placeholder="e.g. 10:00 AM EST"
                            value={editedOrder.scheduleTime}
                            onChange={(e) => setEditedOrder({...editedOrder, scheduleTime: e.target.value})}
                            className="bg-bg-primary h-10 text-xs"
                        />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                        <Label className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Priority</Label>
                        <Select value={editedOrder.priority} onValueChange={(val: any) => setEditedOrder({...editedOrder, priority: val})}>
                            <SelectTrigger className="bg-bg-primary h-10 text-xs uppercase font-bold tracking-wider focus:ring-brand-red"><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="critical">Critical</SelectItem>
                            </SelectContent>
                        </Select>
                        </div>
                        <div className="space-y-2">
                        <Label className="text-[10px] font-bold uppercase tracking-widest text-text-muted">Service Category</Label>
                        <Select value={editedOrder.projectType} onValueChange={(val: any) => setEditedOrder({...editedOrder, projectType: val})}>
                            <SelectTrigger className="bg-bg-primary h-10 text-xs uppercase font-bold tracking-wider focus:ring-brand-red"><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="Installation">Installation</SelectItem>
                                <SelectItem value="Troubleshooting">Troubleshooting</SelectItem>
                                <SelectItem value="Maintenance">Maintenance</SelectItem>
                                <SelectItem value="Survey">Survey</SelectItem>
                                <SelectItem value="Repair">Repair</SelectItem>
                                <SelectItem value="Decommission">Decommission</SelectItem>
                            </SelectContent>
                        </Select>
                        </div>
                    </div>

                    <Separator className="bg-border-sub" />

                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label className="text-[10px] uppercase font-bold text-text-muted ml-1">Technician Allocation</Label>
                            <Select value={editedOrder.assignedTechnicianId || 'unassigned'} onValueChange={(val) => setEditedOrder({ ...editedOrder, assignedTechnicianId: val === 'unassigned' ? undefined : val, status: val === 'unassigned' ? 'unassigned' : 'assigned' })}>
                                <SelectTrigger className="bg-bg-primary h-11 focus:ring-brand-red">
                                    <SelectValue placeholder="Select Technician" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="unassigned" className="text-brand-red font-bold uppercase tracking-widest">UNASSIGNED</SelectItem>
                                    {technicians.filter(t => !t.roles?.includes('client') && !t.role.toLowerCase().includes('client')).map(tech => (
                                        <SelectItem key={tech.id} value={tech.id}>{tech.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label className="text-[10px] uppercase font-bold text-text-muted ml-1">Operational Status</Label>
                            <Select value={editedOrder.status} onValueChange={(val: any) => setEditedOrder({ ...editedOrder, status: val })}>
                                <SelectTrigger className="bg-bg-primary h-11 uppercase font-bold tracking-wider focus:ring-brand-red"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="unassigned">UNASSIGNED</SelectItem>
                                    <SelectItem value="assigned">ASSIGNED</SelectItem>
                                    <SelectItem value="in-progress">IN PROGRESS</SelectItem>
                                    <SelectItem value="completed">COMPLETED</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    <DialogFooter className="bg-bg-tertiary/30 -mx-6 -mb-6 p-6 border-t border-border-default mt-4">
                        <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="h-11 px-8 uppercase font-bold text-[10px] tracking-widest">Close Registry Feed</Button>
                        <Button onClick={handleSaveChanges} className="h-11 px-10 bg-brand-red hover:bg-brand-red-hover uppercase font-bold text-[10px] tracking-widest">
                            Commit Assignment Updates
                        </Button>
                    </DialogFooter>
                </div>
            )}
        </DialogContent>
      </Dialog>
    </>
  );
}
